package gestureinterpreter;

/**
 * Calls the launch method for the application's main class.
 */
public class Driver {

    public static void main(String[] args) {
        Menu.launch(Menu.class, args);
    }
}